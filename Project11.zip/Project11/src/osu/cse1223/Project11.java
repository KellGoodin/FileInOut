/*
 * Project11.java
 * 
 *   A program that reads in a text file that uses a specific input format and uses it to
 *   produce a formatted report for output.
 *   
 *   See the write-up for Homework Lab 13 for more details.
 *   
 *   This skeleton is more "skeletal" than previous labs.  You MUST break your code up into
 *   more methods than what you see here.  Consider methods to display the formatted report
 *   as well as more methods to compute values for the report.
 * 
 * @author Kelland Goodin 
 * 
 */
package osu.cse1223;
import java.io.*;
import java.util.*;

public class Project11 {
	
	public static void main(String[] args) throws IOException {

        Scanner in = new Scanner (System.in);

        System.out.print("Enter Input file name: ");  //while statement to check file

        String fileName = in.nextLine();

        System.out.print("Enter Output file name: ");

        String output = in.nextLine();

        try {

        File input = new File(fileName);

        ArrayList<String> playerNames = readNextSeries(input);

        ArrayList<Integer> playerScores = separatePlayerScores(input);

        ArrayList<Integer> first = groupScores(playerScores);

        System.out.println();

        for(int i = 0; i <= first.size(); i++) {

                      playerScores.remove(0);
        }

        ArrayList<Integer> second = groupScores(playerScores);

        for(int i = 0; i <= second.size(); i++) {

                      playerScores.remove(0);
        }

        ArrayList<Integer> third = groupScores(playerScores);    

        for(int i = 0; i <= third.size(); i++) {
                      playerScores.remove(0);
        }

        ArrayList<Integer> fourth = groupScores(playerScores);
       
        int median1 = getMedian(first);

        int median2 = getMedian(second);

        int median3 = getMedian(third);

        int median4 = getMedian(fourth);

       
        int average1 = getAverage(first);

        int average2 = getAverage(second);

        int average3 = getAverage(third);

        int average4 = getAverage(fourth);
        

        int max1 = getMax(first);

        int max2 = getMax(second);

        int max3 = getMax(third);

        int max4 = getMax(fourth);

       
        int min1 = getMin(first);

        int min2 = getMin(second);

        int min3 = getMin(third);

        int min4 = getMin(fourth);

        PrintWriter printOut = new PrintWriter(output);

        printOut.printf("Name                     Mean     Median     Max     Min %n");
        printOut.printf("------------------      ------    ------    ----    ---- %n");
   
        printOut.printf("%-15s %10d %10d %8d %8d %n", playerNames.get(0), median1, average1, max1, min1);

        printOut.printf("%-15s %10d %10d %8d %8d %n",playerNames.get(1), median2, average2, max2, min2);

        printOut.printf("%-15s %9d %10d %8d %8d %n",playerNames.get(2), median3, average3, max3, min3);

        printOut.printf("%-15s %10d %10d %8d %8d %n", playerNames.get(3), median4, average4, max4, min4);

        printOut.printf("%n");
        

        printOut.printf("Total number of participants: %d %n", playerNames.size());

        int high = getHighAvg(average1, average2, average3, average4);

        int low = getLowAvg(average1, average2, average3, average4);

        printOut.printf("Highest average score: %s (%d) %n", playerNames.get(2), high );

        printOut.printf("Lowest average score: %s (%d) %n", playerNames.get(3),low);

        printOut.close();

        } catch(IOException e) {

                      System.out.println("There was a problem reading from " + fileName);

        }

}
//put scores together 
private static ArrayList<Integer> groupScores (ArrayList<Integer> allScores){   

        ArrayList<Integer> newScores = new ArrayList<Integer>();

        int i = 0;

        while(allScores.get(i) != -1) {

                      newScores.add(allScores.get(i));

                      i++;

        }

return newScores;

}

private static ArrayList<String> readNextSeries(File inputFile) throws IOException{      

        Scanner inputFile2 = new Scanner(inputFile);

        ArrayList<String> names = new ArrayList<String>();

        while(inputFile2.hasNext() == true) {

                      String line = inputFile2.nextLine();

                      if(line.length() > 3) {

                                    names.add(line);

                      }

        }

return names;

}
//separate scores and make them integers from string 

private static ArrayList<Integer> separatePlayerScores (File inputFile) throws IOException{      

        Scanner inputFile2 = new Scanner(inputFile);

        ArrayList<String> scores = new ArrayList<String>();

        ArrayList<Integer> playerScores = new ArrayList<Integer>();

        while(inputFile2.hasNext() == true) {  

                      String line = inputFile2.nextLine();

                      if(line.length() < 4) {

                                    int score = Integer.parseInt(line); 

                                    playerScores.add(score);

                      }

        }

        return playerScores;

}

// Given a ArrayList<Integer> of integers, compute the median of the list and return it to
// the calling program.

private static int getMedian(ArrayList<Integer> inList) {      

        Collections.sort(inList);

        int check = inList.size()%2;

        int median = 0;

        if(check == 0) {

            int firstNum = (inList.size()/2)-1;

            int secondNum = firstNum+1;

            median = (inList.get(firstNum)+inList.get(secondNum))/2; 

        }

        else if(check != 0) {

                      int find = (inList.size()/2);

                      median  = (int)inList.get(find); 
}

return median;

}
// Given a ArrayList<Integer> of integers, compute the average of the list and return it to
// the calling program.

private static int getAverage(ArrayList<Integer> inList) {

       

        int total = 0;

        for(int i = 0; i < inList.size(); i++) {

                      total = total + inList.get(i);

        }

        int average = total/(inList.size());

return average;

}

private static int getMax(ArrayList<Integer>inList) {

       

        int max = Collections.max(inList);

        return max;
}

private static int getMin(ArrayList<Integer>inList) {     

        int min = Collections.min(inList);

        return min; 

}  
//helps order code in the displayed file 
private static void display(int num, ArrayList<String> names, int med, int mean, int max, int min) {      

        String name = names.get(num);

        System.out.print(name);

        for(int i = 0; i < (26-name.length()); i++) {

                      System.out.print(" ");

        }

        System.out.print(mean + "      ");

        System.out.print(med + "    ");

        System.out.print(max);

        int length = String.valueOf(min).length();

        for(int i = 0; i < (6-length); i++) {

                      System.out.print(" ");

        }

        System.out.print(min);
}
//makes overall high 
private static int getHighAvg(int avg1, int avg2, int avg3, int avg4) {
	
        int[] arr = new int[4];

        arr[0] = avg1;

        arr[1] = avg2;

        arr[2] = avg3;

        arr[3] = avg4;

        Arrays.sort(arr);

        int high = arr[arr.length-1];

        return high;

}
//makes overall low 
private static int getLowAvg(int avg1, int avg2, int avg3, int avg4) { 

        int[] arr = new int[4];

        arr[0] = avg1;

        arr[1] = avg2;

        arr[2] = avg3;

        arr[3] = avg4;

        Arrays.sort(arr);

        int low = arr[0];   

        return low;

      }
}